﻿using EF_Ddd.EF;
using System;
using System.Collections.Generic;
using System.Text;
using System.Threading.Tasks;

namespace EF_Ddd.DDD
{
    public class UserCreatedEvent : IDomainEvent
    {
        public UserCreatedEvent(Guid id)
        {
            Id = id;
        }

        public Guid Id { get; set; }
    }

    public interface IEventHandler<in T> where T : IDomainEvent
    {
        Task HandleAsync(T @event);
    }

    public class UserCreatedEventHandler : IEventHandler<UserCreatedEvent>
    {
        public async Task HandleAsync(UserCreatedEvent @event)
        {
            //Fetch the user from database by id, log this event, store some data etc.
        }
    }
}
