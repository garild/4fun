﻿using EF_Ddd.EF;
using System;
using System.Collections.Generic;
using System.Text;

namespace EF_Ddd.DDD
{
    //Marker
    public interface IEvent
    {
    }

    public abstract class Entity : IEntity
    {
        private readonly IDictionary<Type, IDomainEvent> _events = new Dictionary<Type, IDomainEvent>();

        public IEnumerable<IDomainEvent> Events => _events.Values;
        

        protected void AddEvent(IDomainEvent @event)
        {
            _events[@event.GetType()] = @event;
        }

        protected void ClearEvents()
        {
            _events.Clear();
        }
    }

    public interface IEntity
    {
        IEnumerable<IDomainEvent> Events { get; }
    }
}
