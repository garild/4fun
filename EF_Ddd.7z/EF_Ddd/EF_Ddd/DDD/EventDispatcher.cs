﻿using System;
using System.Collections;
using System.Collections.Generic;
using System.Linq;
using System.Threading.Tasks;

namespace EF_Ddd.DDD
{
    public interface IHandler<in T> where T : IDomainEvent
    {
        void Handle(T domainEvent);
    }

    public interface IDomainEvent
    {
    }

    public interface IEventDispatcher
    {
        void Dispatch<TEvent>(TEvent eventToDispatch) where TEvent : IDomainEvent;
    }

    public class EventDispatcher : IEventDispatcher
    {
        private readonly IServiceProvider _context;

        public EventDispatcher(IServiceProvider context)
        {
            _context = context;
        }

        public void Dispatch<TEvent>(TEvent eventToDispatch) where TEvent : IDomainEvent
        {
            foreach (dynamic handler in GetHandlers(eventToDispatch))
            {
                handler.Handle((dynamic)eventToDispatch);
            }
        }

        private IEnumerable GetHandlers<TEvent>(TEvent eventToDispatch) where TEvent : IDomainEvent
        {
            return (IEnumerable)_context.GetService(
                typeof(IEnumerable<>).MakeGenericType(
                    typeof(IHandler<>).MakeGenericType(eventToDispatch.GetType())));
        }
    }
}
