﻿using EF_Ddd.DDD;
using Microsoft.EntityFrameworkCore;
using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;

namespace EF_Ddd.EF
{
    public class EFContext : DbContext
    {
        private readonly IEventDispatcher _eventDispatcher;
        public DbSet<User> Users;
        public EFContext(IEventDispatcher eventDispatcher)
        {
            _eventDispatcher = eventDispatcher;
        }

        public override int SaveChanges()
        {
            var numberOfChanges = base.SaveChanges();

            var entities = GetDomainEventEntities().Where(p => p.Events.Any()).ToList();

            entities.ForEach(p =>
            {
                p.Events.ToList()
                .ForEach(
                    @event => _eventDispatcher.Dispatch(@event)
                    );
            });

            return numberOfChanges;
        }

        private IEnumerable<IEntity> GetDomainEventEntities()
        {
            return ChangeTracker.Entries<IEntity>()
                .Select(po => po.Entity)
                .Where(p => p.Events.Any())
                .ToArray();
        }
    }
}
