﻿using EF_Ddd.DDD;
using System;
using System.Collections.Generic;
using System.Text;

namespace EF_Ddd.EF
{
    public class User : Entity
    {
        public string Email { get; protected set; }
        public string Password { get; protected set; }
        public DateTime UpdatedAt { get; protected set; }

        public User()
        {
        }

        public void Create()
        {
            AddEvent(new UserCreatedEvent(Guid.NewGuid()));
        }
    }
 
}
