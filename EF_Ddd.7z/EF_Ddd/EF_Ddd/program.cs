﻿using EF_Ddd.EF;
using System;
using System.Collections.Generic;
using System.Text;

namespace EF_Ddd
{
    public static class program
    {
       
    }
}


