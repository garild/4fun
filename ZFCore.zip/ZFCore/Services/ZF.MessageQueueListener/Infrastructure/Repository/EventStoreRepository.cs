﻿using Database.Contexts;
using Database.Entities.Events;
using System.Data.SqlClient;
using System.Threading.Tasks;

namespace EventSourceScheduler.Infrastructure.Repository
{
    public class EventStoreRepository : IEventStoreRepository
    {
        private const string TableName = "EventStore";
        private readonly SqlConnection _sqlConnection;
        private readonly EventStoreContext _eventStoreContext;

        public EventStoreRepository(EventStoreContext eventStoreContext)
        {
            _eventStoreContext = eventStoreContext;
        }

        public async Task Save(EventMessage message)
        {
            _eventStoreContext.Add(message);
           await _eventStoreContext.SaveChangesAsync();
        }
    }
}
