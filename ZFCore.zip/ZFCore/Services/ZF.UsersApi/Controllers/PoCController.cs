﻿using Database.Contexts;
using ZF.UsersApi.Domain;
using Microsoft.AspNetCore.Mvc;
using System.Data.SqlClient;

namespace ZF.IdentityServer.Controllers
{
    [Route("api/[controller]")]
    public class PoCController : Controller
    {
        [HttpGet]
        public string Get()
        {
            return "User Api work nice";
        }
    }
}
