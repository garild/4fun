﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Threading.Tasks;
using Database.Entities.IdentityServer.Users;
using Microsoft.AspNetCore.Mvc;
using ZF.UsersApi.Infrastructure.Repository;

namespace ZF.UsersApi.Controllers
{
    [Route("api/[controller]/[action]")]
    public class UserController : Controller
    {
        private readonly IUserRepository _userRepository;

        public UserController(IUserRepository userRepository)
        {
            _userRepository = userRepository;
        }

        [HttpGet]
        public JsonResult Find(string userName)
        {
            return Json(_userRepository.FindByLogin(userName));
        }

        [HttpGet]
        public JsonResult FindById(int userId)
        {
            return Json(_userRepository.Find(userId));
        }

        [HttpPost]
        public void Update(string userLogin, AccountStatusEnum status)
        {
            var user = _userRepository.FindByLogin(userLogin);

            user.Status = status;

            _userRepository.Update(user);
        }
    }
}