﻿using ZF.UsersApi.Domain;

namespace ZF.UsersApi.Infrastructure.Repository
{
    public interface IUserRepository
    {
        User FindByLogin(string userName);
        User Find(int id);
        void Update(User user);
    }
}
