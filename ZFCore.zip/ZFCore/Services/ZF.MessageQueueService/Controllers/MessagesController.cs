﻿using Microsoft.AspNetCore.Mvc;
using RabbitMQ.Interface;

namespace Boutique.EventBusSubscriber.api.Controllers
{
    [Route("api/[controller]/[action]")]
    public class MessagesController : Controller
    {
        private readonly IRabbitMqReadClient _readClient;
        private readonly IRabbitMqWriteClient _writeClient;

        public MessagesController(IRabbitMqReadClient readClient, IRabbitMqWriteClient writeClient)
        {
            _readClient = readClient;
            _writeClient = writeClient;
        }

        [HttpGet]
        public string Read()
        {
            var message = string.Empty;
            _readClient.Read(p => message = p, "Messages");

            return message;
        }

        [HttpGet("{queue}/{message}")]
        public string Write(string message, string @queue)
        {
            return $"{@queue} : {message}";
        }
    }
}