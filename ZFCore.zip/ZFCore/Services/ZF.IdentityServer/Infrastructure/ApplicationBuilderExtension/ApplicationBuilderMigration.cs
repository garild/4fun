﻿using Database.Contexts;
using Microsoft.AspNetCore.Builder;
using Microsoft.EntityFrameworkCore;
using Microsoft.Extensions.DependencyInjection;

namespace ZF.IdentityServer.Infrastructure.ApplicationBuilderExtension
{
    public static class ApplicationBuilderMigration
    {
        public static void AutoMigration(this IApplicationBuilder app)
        {
            using (var scope = app.ApplicationServices.CreateScope())
            {
                var dbContext = scope.ServiceProvider.GetService<IndentityServerContext>();
                dbContext.Database.EnsureCreated();
                dbContext.Database.Migrate();
            }
        }
    }
}

