﻿using Database.Entities.IdentityServer;
using Database.Entities.IdentityServer.Users;

namespace ZF.IdentityServer.Infrastructure.Services
{
    public interface IUserService
    {
        User Save(string userLogin, string password,RoleEnum roleEnum,AccountStatusEnum accountStatus);
        void Update(string userLogin, AccountStatusEnum accountStatus, RoleEnum role);
        void PublishNewUser(User user);
    }
}
