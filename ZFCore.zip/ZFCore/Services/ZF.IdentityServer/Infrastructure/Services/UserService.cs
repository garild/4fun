﻿using Auth.Provider;
using Database.Contexts;
using Database.Entities.IdentityServer;
using Database.Entities.IdentityServer.Users;
using Microsoft.AspNetCore.Identity;
using Newtonsoft.Json;
using RabbitMQ.Interface;
using System.Linq;

namespace ZF.IdentityServer.Infrastructure.Services
{
    public class UserService : IUserService
    {
        private readonly IJwtProvider _jwtProvider;
        private readonly IndentityServerContext _context;
        private readonly IRabbitMqWriteClient _rabbitMqWriteClient;
        private readonly IPasswordHasher<User> _passwordHasher;

        public UserService(IJwtProvider jwtProvider, IndentityServerContext context, IRabbitMqWriteClient rabbitMqWriteClient)
        {
            _jwtProvider = jwtProvider;
            _context = context;
            _rabbitMqWriteClient = rabbitMqWriteClient;
            _passwordHasher = new PasswordHasher<User>();
        }

        public User Save(string userLogin, string password, RoleEnum roleEnum, AccountStatusEnum accountStatus = AccountStatusEnum.Active)
        {
            var data = new User
            {
                Login = userLogin,
                Password = password,
                Role = roleEnum,
                Status = accountStatus
            };

            data.Password = _passwordHasher.HashPassword(data, password);

            var newUser = _context.Users.Add(data);

            var jwt = _jwtProvider.Create(userLogin, newUser.Entity.Id);

            data.AccessToken = jwt.AccessToken;
            _context.SaveChanges();

            return newUser.Entity;
        }

        public void Update(string userLogin, AccountStatusEnum accountStatus,RoleEnum role)
        {
            var findUser = _context.Users.First(p => p.Login.ToLower().Equals(userLogin.ToLower()));

            findUser.Status = accountStatus;
            findUser.Role = role;

            _context.Users.Update(findUser);
            _context.SaveChanges();
        }

        public void PublishNewUser(User user)
        {
            var mesasge = JsonConvert.SerializeObject(user);
            _rabbitMqWriteClient.Write(mesasge);
        }
    }
}
