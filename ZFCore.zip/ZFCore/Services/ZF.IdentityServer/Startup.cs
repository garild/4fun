﻿using Microsoft.AspNetCore.Builder;
using Microsoft.AspNetCore.Hosting;
using Microsoft.AspNetCore.Mvc;
using Microsoft.Extensions.Configuration;
using Microsoft.Extensions.DependencyInjection;
using Microsoft.Extensions.Logging;
using NLog.Extensions.Logging;
using Swashbuckle.AspNetCore.Swagger;
using Auth.ServicesCollection;
using ZF.IdentityServer.Infrastructure.Formater;
using Auth.Provider;
using Database;
using Database.Contexts;
using ZF.IdentityServer.Infrastructure.ApplicationBuilderExtension;
using ZF.IdentityServer.Infrastructure.Middleware;
using ZF.IdentityServer.Infrastructure.Services;
using RabbitMQ.ServicesCollection;
using System.Reflection;
using RabbitMQ.Settings;

namespace ZF.IdentityServer
{
    public class Startup
    {
        public IConfiguration Configuration { get; }

        public Startup(IHostingEnvironment env)
        {
            var builder = new ConfigurationBuilder()
                .AddJsonFile($"appsettings.{env.EnvironmentName}.json", true)
                .AddJsonFile("appsettings.json");

            Configuration = builder.Build();
        }
      
        // This method gets called by the runtime. Use this method to add services to the container.
        public void ConfigureServices(IServiceCollection services)
        {
            services.Configure<RabbitMqSettings>(Configuration.GetSection("rabbitMq"));

            //Read primitive type in HTTP Request
            services
                .AddMvc(p=> p.InputFormatters.Insert(0, new RawRequestBodyFormatter()))
                .SetCompatibilityVersion(CompatibilityVersion.Version_2_1);

            //Swagger implementation
            services.AddSwaggerGen(c =>
            {
                c.SwaggerDoc("v1", new Info { Title = "ZF Core IdentityServer ", Version = "v1" });
            });

            //Base settings
            services.Configure<JwtSettings>(Configuration.GetSection("jwt"));
            services.Configure<SqlSettings>(Configuration.GetSection("sql"));

            //Default auth provider
            services.AddAuthJwt(Configuration);

            //RabbitMq
            services.AddRabbitMq(Assembly.GetExecutingAssembly());

            //Register in IoC abstractions/services/repostories etc
            services.AddDbContext<IndentityServerContext>();
            services.AddScoped<IUserService, UserService>();
        }

        // This method gets called by the runtime. Use this method to configure the HTTP request pipeline.
        public void Configure(IApplicationBuilder app, IHostingEnvironment env, ILoggerFactory loggerFactory)
        {
            if (env.IsDevelopment())
            {
                app.UseDeveloperExceptionPage();
                loggerFactory.AddDebug();
                loggerFactory.AddConsole(true);
                app.AutoMigration();
            }
            else
            {
                app.UseHsts();
            }

            app.UseMiddleware<ErrorHandlerMiddleware>();
            app.UseHttpsRedirection();
            app.UseMvc();

            app.UseSwagger(c => c.RouteTemplate = "api/{documentName}/swagger.json");
            app.UseSwaggerUI(c => c.SwaggerEndpoint("/api/v1/swagger.json", "ZF WebApi v1.0"));

            loggerFactory.AddNLog();
        }
    }
}
