using Auth.Provider;
using Database;
using Database.Contexts;
using Database.Entities.IdentityServer;
using Database.Entities.IdentityServer.Users;
using Microsoft.Extensions.Options;
using NSubstitute;
using NUnit.Framework;
using RabbitMQ.Interface;
using System.Data.SqlClient;
using ZF.IdentityServer.Infrastructure.Services;

namespace UserServiceIntegrationTest
{
    [TestFixture]
    [Category("IntegrationTest")]
    public class UserServiceTest
    {
        private readonly IUserService userService;
        private readonly IJwtProvider jwtProvider;
        private readonly IndentityServerContext indentityServerContext;
        public UserServiceTest()
        {
            var jtw = new JwtSettings
            {
                SecretKey = "gRG9lIiwiaWF0IjoxNTE2MjM5MDIyfQ",
                ExpiryMinutes = 5,
                Issuer = "http://localhost"
            };
            var sql = new SqlSettings
            {
                ConnectionString = "Data Source=(localdb)\\MSSQLLocalDB;Initial Catalog=ZF.IdentityServer;Integrated Security=True;Connect Timeout=0;",
                Database = "ZF.IdentityServer",
                InMemory = true
                
            };

            var jwtSettings = Options.Create(jtw);
            var sqlSettings = Options.Create(sql);
            var mqSettings = Substitute.For<IRabbitMqWriteClient>();


            jwtProvider = new JwtProvider(jwtSettings);

            indentityServerContext = new IndentityServerContext(sqlSettings);
            userService = new UserService(jwtProvider, indentityServerContext, mqSettings);
        }
       
        [Test,Order(1)]
        public void Should_Add_New_User_Successfuly_And_Grant_AccessToken()
        {
            //Arrange

            //Act
            var newUser = userService.Save("Bogdan", "123", RoleEnum.User, AccountStatusEnum.Active);

            //Assert
            Assert.AreEqual(newUser.Login, "Bogdan");
            Assert.IsNotEmpty(newUser.AccessToken);
        }

        [Test, Order(2)]
        public void Should_Update_User_Successfuly()
        {
            //Arrange
            var newUser = userService.Save("Bogdan", "123",RoleEnum.User,AccountStatusEnum.Active);

            //Act
            userService.Update(newUser.Login, AccountStatusEnum.Inactive, RoleEnum.SuperAdmin);
            var updatedUser = indentityServerContext.Users.Find(newUser.Id);

            //Assert
            Assert.AreEqual(newUser.Role, updatedUser.Role);
            Assert.AreEqual(newUser.Status, updatedUser.Status);
            Assert.AreEqual(newUser.Id, updatedUser.Id);
        }


    }
}
