﻿using Database.Entities.IdentityServer.Users;
using System;
using System.ComponentModel.DataAnnotations;

namespace Database.Entities.IdentityServer
{
    public class User
    {
        [Key]
        public int Id { get; set; }
        public string Login { get; set; }
        public string Password { get; set; }
        public AccountStatusEnum Status { get; set; }
        public RoleEnum Role { get; set; }
        public string AccessToken { get; set; }
        public DateTime CreateDate => DateTime.Today;
        public DateTime? ModificateDate { get; set; }
    }
}
