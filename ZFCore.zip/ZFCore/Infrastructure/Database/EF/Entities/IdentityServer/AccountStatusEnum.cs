﻿namespace Database.Entities.IdentityServer.Users
{
    public enum AccountStatusEnum
    {
        Active = 1,
        Inactive = 2,
    }
}
