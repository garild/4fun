﻿namespace Database.Entities.IdentityServer.Users
{
    public enum RoleEnum
    {
        User = 1,
        Admin = 2,
        SuperAdmin = 3,
        DevOps = 4
    }
}
