﻿
namespace RabbitMQ.Interface
{
    public interface IRabbitMqWriteClient
    {
        void Write(string message);
    }
}