﻿CREATE TABLE [dbo].[Log]
(
	[Id] INT NOT NULL IDENTITY(1,1),
	[Status] INT NOT NULL,
	[SourceMessage] NVARCHAR(MAX) NOT NULL,
	[ErrorMessage]  NVARCHAR(MAX) NOT NULL,
	[InvokedBy] VARCHAR(500),
	[IsProcessed] BIT NOT NULL DEFAULT 0,
	[CreateDate] DATETIME2(1) NOT NULL,
	[UpdateDate] DATETIME2(1) NULL,

	CONSTRAINT [PK_Log_Id] PRIMARY KEY CLUSTERED  ([Id] DESC)

) ON [FG_PrimaryKey] TEXTIMAGE_ON [FG_Text]

GO

CREATE NONCLUSTERED INDEX [IX_Log_Status] ON [dbo].[Log] ([Status]) ON [FG_IDX]
