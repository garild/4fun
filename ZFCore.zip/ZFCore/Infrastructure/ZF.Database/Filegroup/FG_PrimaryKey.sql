﻿ALTER DATABASE [$(DatabaseName)]
	ADD FILEGROUP [FG_PrimaryKey]
