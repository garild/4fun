﻿using Auth.Provider;
using Microsoft.AspNetCore.Authentication.Cookies;
using Microsoft.AspNetCore.Authentication.JwtBearer;
using Microsoft.Extensions.Configuration;
using Microsoft.Extensions.DependencyInjection;
using Microsoft.IdentityModel.Tokens;
using System.Reflection;
using System.Text;


namespace Auth.ServicesCollection
{
    public static class ServiceCollection
    {
        public static void AddAuthJwt(this IServiceCollection services, IConfiguration configuration, params Assembly[] assemblies)
        {
            services.AddScoped<IJwtProvider, JwtProvider>();
           

            var jwtSettings = new JwtSettings();
            configuration.GetSection("jwt").Bind(jwtSettings);

            services.AddAuthentication(JwtBearerDefaults.AuthenticationScheme)
                .AddJwtBearer(options =>
                {
                    options.Audience = "http://localhost:5001/";
                    options.Authority = "http://localhost:5001/";
                    options.RequireHttpsMetadata = false;
                    options.SaveToken = true;
                    options.TokenValidationParameters = new TokenValidationParameters
                    {
                        ValidIssuer = jwtSettings.Issuer,
                        RequireExpirationTime = true,
                        ValidateIssuer = true,
                        ValidateIssuerSigningKey = true,
                        IssuerSigningKey = new SymmetricSecurityKey(Encoding.UTF8.GetBytes(jwtSettings.SecretKey)),
                        ValidateAudience = true,
                        ValidateLifetime = true
                    };
                });
        }

        public static void AddFacebookAuth(this IServiceCollection services, IConfiguration configuration, params Assembly[] assemblies)
        {
            var fbUserSercret = new FacebookSettings();
            configuration.GetSection("facebookAuth").Bind(fbUserSercret);

            services.AddAuthentication(options =>
           {
               options.DefaultChallengeScheme = CookieAuthenticationDefaults.AuthenticationScheme;
               options.DefaultAuthenticateScheme = CookieAuthenticationDefaults.AuthenticationScheme;
               options.DefaultSignInScheme = CookieAuthenticationDefaults.AuthenticationScheme;
           })
           .AddFacebook(facebookOptions=>
           {
               facebookOptions.AppId = fbUserSercret.AppId;
               facebookOptions.AppSecret = fbUserSercret.AppSecret;
           })
           .AddCookie();
        }
    }
}
