﻿using Auth.Claims;
using Auth.Provider;
using Microsoft.AspNetCore.Authentication.Cookies;
using Microsoft.AspNetCore.Authentication.JwtBearer;
using Microsoft.Extensions.Configuration;
using Microsoft.Extensions.DependencyInjection;
using Microsoft.IdentityModel.Tokens;
using System.Reflection;
using System.Text;


namespace Auth.ServicesCollection
{
    public static class ServiceCollection
    {
        public static void AddAuthJwt(this IServiceCollection services, IConfiguration configuration, params Assembly[] assemblies)
        {
            services.AddScoped<IJwtProvider, JwtProvider>();
           
            services.AddAuthorization(option =>
            {
                option.AddPolicy("Admin", p => { p.Requirements.Add(new ClaimsRequirement()); });
            });

            var jwtSettings = new JwtSettings();
            configuration.GetSection("jwt").Bind(jwtSettings);

            services.AddAuthentication(JwtBearerDefaults.AuthenticationScheme)
                .AddJwtBearer(cfg =>
                {
                    cfg.TokenValidationParameters = new TokenValidationParameters
                    {
                        ValidIssuer = jwtSettings.Issuer,
                        RequireExpirationTime = true,
                        ValidateIssuer = true,
                        ValidateIssuerSigningKey = true,
                        IssuerSigningKey = new SymmetricSecurityKey(Encoding.UTF8.GetBytes(jwtSettings.SecretKey)),
                        ValidateAudience = false,
                        ValidateLifetime = true
                    };
                });
        }

        public static void AddFacebookAuth(this IServiceCollection services, IConfiguration configuration, params Assembly[] assemblies)
        {
            var fbUserSercret = new FacebookSettings();
            configuration.GetSection("facebookAuth").Bind(fbUserSercret);

            services.AddAuthentication(options =>
           {
               options.DefaultChallengeScheme = CookieAuthenticationDefaults.AuthenticationScheme;
               options.DefaultAuthenticateScheme = CookieAuthenticationDefaults.AuthenticationScheme;
               options.DefaultSignInScheme = CookieAuthenticationDefaults.AuthenticationScheme;
           })
           .AddFacebook(facebookOptions=>
           {
               facebookOptions.AppId = "297876904399119";
               facebookOptions.AppSecret = "6aa93bc81f363fb853e2c4a7f08d2849";
           })
           .AddCookie();
        }
    }
}
