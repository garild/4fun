﻿using System;
using System.Collections.Generic;
using System.Text;

namespace Auth.Provider
{
    public class FacebookSettings
    {
        public string AppId { get; set; }
        public string AppSecret { get; set; }
    }
}
