﻿using Auth.Providers.Jwt;
using System;
using System.Collections.Generic;
using System.Text;

namespace Auth.Provider
{
    public class JsonWebToken
    {
        public string AccessToken { get; set; }
        public ICollection<RolesEnum> Roles { get; set; }
    }
}
