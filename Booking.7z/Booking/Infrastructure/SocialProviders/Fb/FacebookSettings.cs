﻿using System;
using System.Collections.Generic;
using System.Text;

namespace SocialProviders.Fb
{
    public class FacebookSettings
    {
        public string AppId { get; set; }
        public string AppSecret { get; set; }
    }
}
