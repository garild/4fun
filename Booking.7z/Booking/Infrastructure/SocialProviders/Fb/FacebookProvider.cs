﻿using Microsoft.Extensions.Options;

namespace SocialProviders.Fb
{
    public class FacebookProvider 
    {
        readonly string FacebookAPIUlr = "https://graph.facebook.com/";
        private readonly FacebookSettings _options;

        public FacebookProvider(IOptions<FacebookSettings> options)
        {
            _options = options.Value;
        }

        public
    }
}
