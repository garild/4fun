﻿using System;
using System.Collections.Generic;
using System.Text;

namespace RabbitMQ
{
    public enum MqDeliveryModeEnum
    {
        NonPersistent = 1,
        Persistence = 2
    }
}
