﻿using CQRS.Gate;
using System;
using System.Transactions;

namespace CQRS.Decorators
{
    public class SqlTransactionDecorator : IGate
    {
        private readonly IGate _commandGateway;

        public SqlTransactionDecorator(IGate commandGateway)
        {
            _commandGateway = commandGateway;
        }

        public void Call<TCommand>(TCommand command)
        {
            using (var scopeTransaction = new TransactionScope(TransactionScopeOption.Required))
            {
                try
                {
                    _commandGateway.Call(command);
                    scopeTransaction.Complete();
                }
                catch (Exception)
                {
                    scopeTransaction.Dispose();
                }
            }
        }

        public TResult Call<TCommand, TResult>(TCommand command)
        {
            using (var scopeTransaction = new TransactionScope(TransactionScopeOption.Required))
            {
                try
                {
                   var result = _commandGateway.Call<TCommand,TResult>(command);
                    scopeTransaction.Complete();
                    return result;
                }
                catch (Exception)
                {
                    scopeTransaction.Dispose();
                    return default(TResult);
                }
            }
        }
    }
}
