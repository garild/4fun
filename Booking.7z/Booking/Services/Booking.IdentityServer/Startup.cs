﻿using Auth.ServicesCollection;
using Booking.DataUsers;
using Booking.DataUsers.Application.Commands;
using Booking.DataUsers.Infrastructure.ServicesCollection;
using Booking.IdentityServer.Infrastructure;
using Booking.IdentityServer.Infrastructure.ApplicationBuilderExtension;
using CQRS.Command;
using CQRS.DI;
using Microsoft.AspNetCore.Builder;
using Microsoft.AspNetCore.Hosting;
using Microsoft.AspNetCore.Http;
using Microsoft.AspNetCore.Mvc;
using Microsoft.Extensions.Configuration;
using Microsoft.Extensions.DependencyInjection;
using Microsoft.Extensions.DependencyInjection.Extensions;
using Microsoft.Extensions.Logging;

namespace Booking.IdentityServer
{
    public class Startup
    {
        public Startup(IConfiguration configuration)
        {
            Configuration = configuration;
        }

        public IConfiguration Configuration { get; }

        // This method gets called by the runtime. Use this method to add services to the container.
        public void ConfigureServices(IServiceCollection services)
        {
            services.AddFacebookAuth(Configuration);

            services.AddCqrs(BookingDataUserAssemblyInformation.Assemblies);
            services.AddMvc(
                options => options.InputFormatters.Insert(0,new RawRequestBodyFormatter()))
            .SetCompatibilityVersion(CompatibilityVersion.Version_2_1);

            services.TryAddSingleton<IHttpContextAccessor, HttpContextAccessor>();
            services.AddDataProtection();
            services.AddUserDbContext(Configuration);
        }

        // This method gets called by the runtime. Use this method to configure the HTTP request pipeline.
        public void Configure(IApplicationBuilder app, IHostingEnvironment env,ILoggerFactory loggerFactory)
        {
            if (env.IsDevelopment())
            {
                loggerFactory.AddConsole(Configuration.GetSection("Logging"));
                app.AutoMigration();
                app.UseDeveloperExceptionPage();
            }
            else
            {
                app.UseHsts();
            }
            using (var scope = app.ApplicationServices.CreateScope())
            {
                var testt = scope.ServiceProvider.GetService<ICommandHandler<UserLoginCommand>>();
            }

            app.UseAuthentication();
            app.UseHttpsRedirection();
            app.UseMvc();
        }
    }
}
