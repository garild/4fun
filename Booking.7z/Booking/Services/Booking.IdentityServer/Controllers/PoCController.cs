﻿using System.Linq;
using System.Security.Claims;
using Microsoft.AspNetCore.Http;
using Microsoft.AspNetCore.Mvc;

namespace Booking.IdentityServer.Controllers
{
    [Route("/")]
    public class PoCController : Controller
    {
        private readonly IHttpContextAccessor _httpContextAccessor;

        public PoCController(IHttpContextAccessor httpContextAccessor)
        {
            _httpContextAccessor = httpContextAccessor;
        }
        public string Index()
        {
            var userName = User.Identity.IsAuthenticated ? User.Identity.AuthenticationType : "Janusz";
            var userSurname = User.Claims.FirstOrDefault(p => p.Type == ClaimTypes.Surname).Value;
            var displayName = User.Claims.FirstOrDefault(p => p.Type == ClaimTypes.GivenName).Value;
            var cookie = _httpContextAccessor.HttpContext.Request.Cookies;
            return $"Hello world > {userName}, {userSurname} or {displayName}";
        }
    }
}