﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Threading.Tasks;
using Microsoft.AspNetCore.Mvc;

namespace Booking.IdentityServer.Controllers
{
    [Route("/")]
    public class PoCController : Controller
    {
        public string Index()
        {
            var userName = User.Identity.IsAuthenticated ? User.Identity.Name : "Janusz";

            return $"Hello world > {userName}";
        }
    }
}