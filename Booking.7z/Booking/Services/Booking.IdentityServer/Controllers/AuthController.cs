﻿using Booking.Application.Commands;
using CQRS.Gate;
using Microsoft.AspNetCore.Authentication;
using Microsoft.AspNetCore.Mvc;
using Newtonsoft.Json;

namespace Booking.IdentityServer.Controllers
{
    [Route("[controller]/[action]")]
    public class AuthController : Controller
    {
        private readonly IAuthenticationSchemeProvider _authenticationSchemeProvider;
        private readonly IGate _commandGate;

        public AuthController(IAuthenticationSchemeProvider authenticationSchemeProvider, IGate commandGate)
        {
            _authenticationSchemeProvider = authenticationSchemeProvider;
            _commandGate = commandGate;
        }

        [HttpGet]
        public string Index()
        {
            return "Hello world";
        }

        [HttpGet]
        public void SingIn(string provider)
        {
            Redirect($"/{provider}");
        }

        [HttpPost]
        public JsonResult SingIn([FromBody] UserLoginCommand loginCommand)
        {
            var result = _commandGate.Call<UserLoginCommand, CommandResult>(loginCommand);
            return Json(result);
        }
    }
}

