﻿using Booking.DataUsers.Application.Commands;
using CQRS.Gate;
using Microsoft.AspNetCore.Authentication;
using Microsoft.AspNetCore.Http;
using Microsoft.AspNetCore.Mvc;
using System.Linq;
using System.Security.Claims;

namespace Booking.IdentityServer.Controllers
{
    [Route("[controller]/[action]")]
    public class AuthController : Controller
    {
        private readonly IGate _commandGate;
        private readonly IHttpContextAccessor _httpContextAccessor;
        public AuthController(IGate commandGate, IHttpContextAccessor httpContextAccessor)
        {
            _commandGate = commandGate;
            _httpContextAccessor = httpContextAccessor;
        }

        [HttpGet]
        public string Index()
        {
            return "Hello world";
        }

        [HttpGet]
        public void SingIn(string provider)
        {

            Redirect($"/{provider}");

            var fbId = User.Claims.FirstOrDefault(p => p.Type == ClaimTypes.NameIdentifier).Value;
            _commandGate.Call<UserFacebookLoginCommand,CommandResult>(new UserFacebookLoginCommand { FacebookId = fbId, AccessToken = _httpContextAccessor.HttpContext.Request.Cookies.FirstOrDefault().Value, ClaimsPrincipal = User });
        }

        [HttpPost]
        public JsonResult SingIn([FromBody] UserLoginCommand loginCommand)
        {
            var result = _commandGate.Call<UserLoginCommand, CommandResult>(loginCommand);
            return Json(result);
        }
    }
}

