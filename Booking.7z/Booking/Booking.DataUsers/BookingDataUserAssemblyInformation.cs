﻿using System.Reflection;

namespace Booking.DataUsers
{
    public class BookingDataUserAssemblyInformation
    {
        public static Assembly Assemblies { get; } = Assembly.GetExecutingAssembly();
    }
}
