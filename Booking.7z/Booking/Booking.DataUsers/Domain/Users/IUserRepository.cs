﻿using Booking.DataUsers.Treatments.Domain.Users;

namespace Booking.DataUsers.Domain.Users
{
    internal interface IUserRepository
    {
        void Save(User user);
        User FindByLogin(string login);
    }
}
