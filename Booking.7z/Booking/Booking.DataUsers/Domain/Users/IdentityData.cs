﻿using Booking.DataUsers.Domain.Users;
using System;
using System.Collections.Generic;

namespace Booking.DataUsers.Treatments.Domain.Users
{
    public class IdentityData
    {
        private IdentityData() { }

        public IdentityData(string accessToken, List<string> roles, AuthenticateTypeEnum authenticationType, bool isExpired, string issuer, DateTime expires)
        {
            AccessToken = accessToken;
            Roles = roles;
            AuthenticationType = authenticationType;
            IsExpired = isExpired;
            Issuer = issuer;
            Expires = expires;
        }

        public string AccessToken { get; private set; }
        public List<string> Roles { get; private set; } = new List<string>();
        public AuthenticateTypeEnum AuthenticationType { get; private set; }
        public bool IsExpired { get; private set; }
        public string Issuer { get; private set; }
        public DateTime Expires { get; private set; }
    }
}
