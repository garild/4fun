﻿using System;
using System.Collections.Generic;
using System.Text;

namespace Booking.DataUsers.Domain.Users
{
    [Flags]
    public enum RolesTypeEnum
    {
        User = 0,
        Admin = 1 << 0,
        SuperAdmin = 1 << 1,
        SuperUser = 1 << 2,
        FacebookUser = 1 << 3,
        GoogleUser = 1 << 4,
    }
}
