﻿using System;
using System.Collections.Generic;
using System.Text;

namespace Booking.DataUsers.Domain.Users
{
    public enum AuthenticateTypeEnum
    {
        Facebook = 1,
        Google = 2,
        Local = 3
    }
}
