﻿using System;
using System.ComponentModel.DataAnnotations.Schema;

namespace Booking.DataUsers.Treatments.Domain.Users
{
    public class User
    {
        public User(string id, string facebookId, string firstName, string secondName, string surname, string email, string hashedPassword, IdentityData identityData, DateTime createDate, DateTime? updateDate)
        {
            Id = id;
            FacebookId = facebookId;
            FirstName = firstName;
            SecondName = secondName;
            Surname = surname;
            Email = email;
            HashedPassword = hashedPassword;
            IdentityData = identityData;
            CreateDate = createDate;
            UpdateDate = updateDate;
        }

        private User() { }

        public string Id { get; set; }
        public string FacebookId { get; set; }
        public string FirstName { get; set; }
        public string SecondName { get; set; }
        public string Surname { get; set; }
        public string Email { get; set; }
        public string HashedPassword { get; set; }

        [NotMapped]
        public IdentityData IdentityData { get; set; }

        public DateTime CreateDate { get; set; }
        public DateTime? UpdateDate { get; set; }
    }
}
