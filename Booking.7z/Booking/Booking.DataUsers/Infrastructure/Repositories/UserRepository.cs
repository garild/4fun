﻿using Booking.DataUsers.Domain.Users;
using Booking.DataUsers.Infrastructure.DatabaseContext;
using Booking.DataUsers.Treatments.Domain.Users;
using System;

namespace Booking.DataUsers.Infrastructure.Repositories
{
    internal class UserRepository : IUserRepository
    {
        private readonly BookingDataUserContext _sqlSugarClient;

        public UserRepository(BookingDataUserContext sqlSugarClient)
        {
            _sqlSugarClient = sqlSugarClient;
        }

        public User FindByLogin(string login)
        {
            throw new NotImplementedException();
        }

        public void Save(User user)
        {
            _sqlSugarClient.Users.Add(user);

        }
    }
}
