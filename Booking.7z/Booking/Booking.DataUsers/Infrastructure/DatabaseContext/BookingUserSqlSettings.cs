﻿namespace Booking.DataUsers.Infrastructure.DatabaseContext
{
    public class BookingUserSqlSettings
    {
        public string ConnectionString { get; set; }
        public string DatabaseName { get; set; }
        public bool InMemory { get; set; } = false;
    }
}
