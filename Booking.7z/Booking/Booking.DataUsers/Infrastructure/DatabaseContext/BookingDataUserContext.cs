﻿using Booking.DataUsers.Treatments.Domain.Users;
using Microsoft.EntityFrameworkCore;
using Microsoft.Extensions.Options;
using System;

namespace Booking.DataUsers.Infrastructure.DatabaseContext
{
    public class BookingDataUserContext : DbContext
    {
        private readonly BookingUserSqlSettings _sqlOptions;

        public BookingDataUserContext(IOptions<BookingUserSqlSettings> sqlOptions)
        {
            _sqlOptions = sqlOptions.Value;
        }

        protected override void OnConfiguring(DbContextOptionsBuilder optionsBuilder)
        {
            if (optionsBuilder.IsConfigured)
            {
                return;
            }

            if (_sqlOptions.InMemory)
            {
                optionsBuilder.UseInMemoryDatabase("TestDb");
                return;
            }

            optionsBuilder.UseSqlServer(_sqlOptions.ConnectionString, b => b.MigrationsAssembly("Booking.DataUsers"));
        }

        protected override void OnModelCreating(ModelBuilder modelBuilder)
        {
            base.OnModelCreating(modelBuilder);

            modelBuilder.Entity<User>(p =>
            {
                p.Property(property => property.CreateDate).HasColumnType("datetime2(2)");
                p.Property(property => property.UpdateDate).HasColumnType("datetime2(2)");
            });
        }

        public DbSet<User> Users { get; set; }
        public DbSet<IdentityData> IdentityData { get; set; }
    }
}
