﻿using Booking.DataUsers.Domain.Users;
using Booking.DataUsers.Treatments.Domain.Users;
using System;
using System.Linq;
using System.Security.Claims;

namespace Booking.DataUsers.Infrastructure.Adapters
{
    public class SocialNetworkUsersAdapter
    {
        public static User AdaptFacebookUser(ClaimsPrincipal claimsPrincipal, string accessToken,string fbId)
        {
            var name = claimsPrincipal.Claims.FirstOrDefault(p => p.Type == ClaimTypes.GivenName).Value;
            var surname = claimsPrincipal.Claims.FirstOrDefault(p => p.Type == ClaimTypes.Surname).Value;
            var email = claimsPrincipal.Claims.FirstOrDefault(p => p.Type == ClaimTypes.Email).Value;

            var identityData = new IdentityData(accessToken, null , AuthenticateTypeEnum.Facebook, false, AuthenticateTypeEnum.Facebook.ToString(), DateTime.Now.AddMinutes(20));

            return new User(Guid.NewGuid().ToString("N")
                                , fbId
                                , name
                                , null
                                , surname
                                , email
                                , null
                                , identityData
                                , DateTime.Now, null);
        }
    }
}
