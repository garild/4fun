﻿using Booking.DataUsers.Infrastructure.DatabaseContext;
using Microsoft.Extensions.Configuration;
using Microsoft.Extensions.DependencyInjection;

namespace Booking.DataUsers.Infrastructure.ServicesCollection
{
    public static class ServiceCollectionExtension
    {
        public static void AddUserDbContext(this IServiceCollection services, IConfiguration configuration)
        {
            services.Configure<BookingUserSqlSettings>(configuration.GetSection("sql"));
            services.AddDbContext<BookingDataUserContext>();
        }
    }
}
