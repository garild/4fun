﻿using Booking.DataUsers.Application.Commands;
using Booking.DataUsers.Application.Validators;
using Booking.DataUsers.Infrastructure.Adapters;
using Booking.DataUsers.Infrastructure.DatabaseContext;
using CQRS.Command;
using System;
using System.Linq;

namespace Booking.DataUsers.Application.CommandHandlers.User
{
    public class UserLoginCommandHandler : ICommandHandler<UserLoginCommand,CommandResult>, ICommandHandler<UserFacebookLoginCommand, CommandResult>
    {
        private readonly BookingDataUserContext _bookingDataUserContext;
        private UserCommandValidator _commandValidator;

        public UserLoginCommandHandler(BookingDataUserContext bookingDataUserContext)
        {
            _commandValidator = new UserCommandValidator();
            _bookingDataUserContext = bookingDataUserContext;
        }

        public CommandResult Handle(UserLoginCommand command)
        {
            var commandResult = new CommandResult();
            var validationResult = _commandValidator.Validate(command);

            if (!validationResult.IsValid)
            {
                var errorMessage = string.Join(Environment.NewLine, validationResult.Errors);
                commandResult.ErrorMessage = errorMessage;
            }

            return commandResult;
        }

        public CommandResult Handle(UserFacebookLoginCommand command)
        {
            var commandResult = new CommandResult();
            var userExist = _bookingDataUserContext.Users.FirstOrDefault(p => p.FacebookId.Equals(command.FacebookId, StringComparison.OrdinalIgnoreCase));

            if (userExist == null)
            {
                var user = SocialNetworkUsersAdapter.AdaptFacebookUser(command.ClaimsPrincipal, command.AccessToken, command.FacebookId);
                _bookingDataUserContext.Users.Add(user);
                _bookingDataUserContext.SaveChanges();
            }

            return commandResult;
        }
    }
}
