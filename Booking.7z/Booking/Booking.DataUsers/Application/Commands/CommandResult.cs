﻿using System;
using System.Collections.Generic;
using System.Text;

namespace Booking.DataUsers.Application.Commands
{
    public class CommandResult
    {
        public bool IsSuccessed { get; private set; } = true;
        public string ErrorMessage { get; set; }
    }
}
