﻿namespace Booking.DataUsers.Application.Commands
{
    public class UserLoginCommand
    {
        public UserLoginCommand(string login, string password, string authenficationType)
        {
            Login = login;
            Password = password;
            AuthenficationType = authenficationType;
        }

        public string Login { get; set; }
        public string Password { get; set; }
        public string AuthenficationType { get; set; }
    }
}
