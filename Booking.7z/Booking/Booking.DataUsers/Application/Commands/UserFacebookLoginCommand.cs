﻿using System;
using System.Collections.Generic;
using System.Security.Claims;
using System.Text;

namespace Booking.DataUsers.Application.Commands
{
    public class UserFacebookLoginCommand
    {
        public string FacebookId { get; set; }
        public ClaimsPrincipal ClaimsPrincipal { get; set; }
        public string AccessToken { get; set; }
    }
}
