﻿using Booking.DataUsers.Application.Commands;
using FluentValidation;

namespace Booking.DataUsers.Application.Validators
{
    internal class UserCommandValidator : AbstractValidator<UserLoginCommand>
    {
        public UserCommandValidator()
        {
            ValidateName();
            ValidatePassword();
        }
        protected void ValidateName()
        {
            RuleFor(c => c.Login)
                .NotEmpty().WithMessage("Please ensure you have entered the Login")
                .Length(5, 150).WithMessage("The Login must have between 5 and 150 characters");
        }

        protected void ValidatePassword()
        {
            RuleFor(c => c.Password)
              .NotEmpty().WithMessage("Please ensure you have entered the Password")
              .MinimumLength(8).WithMessage("The Password must have minumum 8 characters");
        }
    }
}
