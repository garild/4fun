﻿using System.Reflection;

namespace Booking.Treatments
{
    public class BookingTreatmentsAssemblyInformation
    {
        public static Assembly Assemblies { get; } = Assembly.GetExecutingAssembly(); 
    }
}
