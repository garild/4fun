﻿namespace Booking.Treatments.Domain.TreatmendCardModel
{
    internal class Address
    {
        public Address(string street, string streetNumber, string flatNumber, string city, string country, string postCode)
        {
            Street = street;
            StreetNumber = streetNumber;
            FlatNumber = flatNumber;
            City = city;
            Country = country;
            PostCode = postCode;
        }

        public string Street { get; private set; }
        public string StreetNumber { get; private set; }
        public string FlatNumber { get; private set; }
        public string City { get; private set; }
        public string Country { get; private set; }
        public string PostCode { get; private set; }
    }
}
