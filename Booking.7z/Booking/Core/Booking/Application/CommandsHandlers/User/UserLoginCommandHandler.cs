﻿using Booking.Application.Commands;
using Booking.Application.Validators;
using CQRS.Command;
using Newtonsoft.Json;
using System;

namespace Booking.Application.CommandHandlers.User
{
    public class UserLoginCommandHandler : ICommandHandler<UserLoginCommand,CommandResult>
    {
        private UserCommandValidator _commandValidator;

        public UserLoginCommandHandler()
        {
            _commandValidator = new UserCommandValidator();
        }

        public CommandResult Handle(UserLoginCommand command)
        {
            var commandResult = new CommandResult();
            var validationResult = _commandValidator.Validate(command);

            if (!validationResult.IsValid)
            {
                var errorMessage = string.Join(Environment.NewLine, validationResult.Errors);
                commandResult.ErrorMessage = errorMessage;
            }

            return commandResult;
        }
    }
}
