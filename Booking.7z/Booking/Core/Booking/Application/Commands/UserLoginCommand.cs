﻿namespace Booking.Application.Commands
{
    public class UserLoginCommand
    {
        public string Login { get; set; }
        public string Password { get; set; }
    }
}
