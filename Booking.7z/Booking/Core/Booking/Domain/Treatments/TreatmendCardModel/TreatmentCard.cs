﻿using System;

namespace Booking.Domain.Treatments.TreatmendCardModel
{
    internal class TreatmentCard
    {
        public TreatmentCard(string id,string surname, string forename, string phoneNumber, string email, DateTime dateOfBirth, int age, Address address)
        {
            Surname = surname;
            Forename = forename;
            PhoneNumber = phoneNumber;
            Email = email;
            DateOfBirth = dateOfBirth;
            Age = age;
            Address = address;
            Id = id;
        }

        public string Id { get; private set; }
        public string Surname { get; private set; }
        public string Forename { get; private set; }
        public string PhoneNumber { get; private set; }
        public string Email { get; private set; }
        public DateTime DateOfBirth { get; private set; }
        public int Age { get; private set; }
        public Address Address { get; private  set; }
    }
}
