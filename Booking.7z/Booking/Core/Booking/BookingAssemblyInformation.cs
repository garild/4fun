﻿using System;
using System.Collections.Generic;
using System.Reflection;
using System.Text;

namespace Booking
{
    public class BookingAssemblyInformation
    {
        public static Assembly Assemblies { get; } = Assembly.GetExecutingAssembly(); 
    }
}
