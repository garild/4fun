﻿using Database.Entities.Events;
using System.Threading.Tasks;

namespace EventSourceScheduler.Infrastructure.Repository
{
    public interface IEventStoreRepository
    {
        Task Save(EventMessage message);
    }
}
