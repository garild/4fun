﻿using System.ComponentModel.DataAnnotations.Schema;

namespace ZF.UsersApi.Domain
{
    [Table("Users")]
    public class User
    {
        public int Id { get; set; }
        public string Login { get; set; }
        public Database.Entities.IdentityServer.Users.AccountStatusEnum Status { get; set; }
    }
}
