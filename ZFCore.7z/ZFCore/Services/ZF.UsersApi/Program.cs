﻿using Microsoft.AspNetCore;
using Microsoft.AspNetCore.Hosting;
using Microsoft.Extensions.Logging;
using NLog.Web;

namespace ZF.UsersApi
{
    public class Program
    {
        public static void Main(string[] args)
        {
            CreateWebHostBuilder(args).Build().Run();
        }

        public static IWebHostBuilder CreateWebHostBuilder(string[] args) =>
            WebHost.CreateDefaultBuilder(args)
                .UseNLog()
                .UseKestrel()
                .UseUrls("https://localhost:6007", "http://localhost:6002")
                .UseHealthChecks("/hc")
                .ConfigureLogging(p => p.ClearProviders())
                .UseStartup<Startup>();
    }
}
