﻿using ZF.UsersApi.Domain;
using System;
using System.Data.SqlClient;
using Dapper;
using Dapper.Contrib.Extensions;
using System.Linq;
using Microsoft.AspNetCore.Identity;

namespace ZF.UsersApi.Infrastructure.Repository
{
    public class UserRepository : IUserRepository
    {
        private readonly SqlConnection _sqlConnection;
        private readonly IPasswordHasher<User> _passwordHasher;

        public UserRepository(SqlConnection sqlConnection)
        {
            _sqlConnection = sqlConnection;
            _passwordHasher = new PasswordHasher<User>();
        }

        public User Find(int id)
        {
            var findUser = _sqlConnection.GetAll<User>().AsList().First(p => p.Id == id);

            return findUser;
        }

        public User FindByLogin(string name)
        {
            var userList = _sqlConnection.GetAll<User>().AsList();
            return userList.FirstOrDefault(p => p.Login.ToLower().Equals(name.ToLower()));
        }

        public void Update(User user)
        {
            _sqlConnection.Update(user);
        }
    }
}
