﻿using Microsoft.AspNetCore.Builder;
using Microsoft.AspNetCore.Hosting;
using Microsoft.AspNetCore.Mvc;
using Microsoft.Extensions.Configuration;
using Microsoft.Extensions.DependencyInjection;
using Microsoft.Extensions.HealthChecks;
using Microsoft.Extensions.Logging;
using NLog.Extensions.Logging;
using Swashbuckle.AspNetCore.Swagger;
using System;
using System.Data.SqlClient;
using ZF.UsersApi.Infrastructure.Formater;
using ZF.UsersApi.Infrastructure.Middleware;
using ZF.UsersApi.Infrastructure.Repository;


namespace ZF.UsersApi
{
    public class Startup
    {
        public IConfiguration Configuration { get; }

        public Startup(IHostingEnvironment env)
        {
            var builder = new ConfigurationBuilder()
                .AddJsonFile($"appsettings.{env.EnvironmentName}.json", true)
                .AddJsonFile("appsettings.json");

            Configuration = builder.Build();
        }

        // This method gets called by the runtime. Use this method to add services to the container.
        public void ConfigureServices(IServiceCollection services)
        {
          

            services.AddSwaggerGen(c =>
            {
                c.SwaggerDoc("v1", new Info { Title = "ZF Core DataCenter", Version = "v1" });
            });

            services.AddScoped(p =>
            {
                var connnectionString = Configuration.GetConnectionString("databaseConnectionString");
                return new SqlConnection(connnectionString);
            });

            services.AddScoped<IUserRepository, UserRepository>();
            services.AddHealthChecks(factory =>
            {
                factory.AddSqlCheck("ZF.DataCenter", Configuration["ConnectionStrings:databaseConnectionString"]);
                
            });

            services
              .AddMvc(p =>
              {
                  p.InputFormatters.Insert(0, new RawRequestBodyFormatter());
              }).SetCompatibilityVersion(CompatibilityVersion.Version_2_1);
             
        }

        // This method gets called by the runtime. Use this method to configure the HTTP request pipeline.
        public void Configure(IApplicationBuilder app, IHostingEnvironment env, ILoggerFactory loggerFactory,IApplicationLifetime lifetime)
        {
            if (env.IsDevelopment())
            {
                app.UseDeveloperExceptionPage();
                loggerFactory.AddDebug();
                loggerFactory.AddConsole(true);
            }
            else
            {
                app.UseHsts();
            }

          
            app.UseHttpsRedirection();
            app.UseMvc();
            app.UseMiddleware<ErrorHandlerMiddleware>();

            app.UseSwagger(c => c.RouteTemplate = "api/{documentName}/swagger.json");
            app.UseSwaggerUI(c => c.SwaggerEndpoint("/api/v1/swagger.json", "ZF WebApi v1.0"));
            loggerFactory.AddNLog();
        }
    }
}
