﻿using Microsoft.AspNetCore.Mvc;

namespace ZF.IdentityServer.Controllers
{
    [Route("api/[controller]")]
    public class PoCController : Controller
    {
        [HttpGet]
        public string Get()
        {
            return "Server Identity works nice";
        }
    }
}
