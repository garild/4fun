﻿using Auth.Provider;
using Database.Contexts;
using Database.Entities.IdentityServer;
using Database.Entities.IdentityServer.Users;
using Microsoft.AspNetCore.Identity;
using Microsoft.AspNetCore.Mvc;
using Newtonsoft.Json;
using ZF.IdentityServer.Infrastructure.Services;

namespace ZF.IdentityServer.Controllers
{
    [Route("public/api/[controller]/[action]")]
    public class AuthController
    {
        private readonly IUserService _userService;

        public AuthController(IUserService userService)
        {
            _userService = userService;
        }

        [HttpPost]
        public string Register(string userLogin, string password)
        {
            var savedUser = _userService.Save(userLogin, password,RoleEnum.User,AccountStatusEnum.Active);
            _userService.PublishNewUser(savedUser);

            return JsonConvert.SerializeObject(new { UserId = savedUser.Id, Token = savedUser.AccessToken });
        }
    }
}