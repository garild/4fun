﻿CREATE TABLE [dbo].[Users]
(
	[Id] INT NOT NULL IDENTITY(1,1),
	[Login] NVARCHAR(250) NOT NULL,
	[Status] INT NOT NULL DEFAULT 0,

	CONSTRAINT [PK_Users_Id] PRIMARY KEY CLUSTERED  ([Id] DESC)

) ON [FG_PrimaryKey]

GO

CREATE UNIQUE NONCLUSTERED INDEX [IX_Name] ON [dbo].[Users] ([Login]) ON [FG_IDX]

GO

CREATE NONCLUSTERED INDEX [IX_Account_Status] ON [dbo].[Users] ([Status]) ON [FG_IDX]