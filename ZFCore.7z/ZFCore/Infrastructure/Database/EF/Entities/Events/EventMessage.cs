﻿using System;
using System.ComponentModel.DataAnnotations.Schema;

namespace Database.Entities.Events
{
    [Table("EventStore")]
    public class EventMessage
    {
        public string Type { get; set; }
        public string AdditionalData { get; set; }
        public DateTime CreateAt { get; set; } = DateTime.Now;
    }
}
