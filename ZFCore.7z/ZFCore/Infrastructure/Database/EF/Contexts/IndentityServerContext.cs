﻿using Database;
using Database.Entities.IdentityServer;
using Database.Entities.IdentityServer.Users;
using Microsoft.EntityFrameworkCore;
using Microsoft.Extensions.Options;
using System;

namespace Database.Contexts
{
    public class IndentityServerContext : DbContext
    {
        private readonly SqlSettings _sqlOptions;
        public DbSet<User> Users { get; set; }

        public IndentityServerContext(IOptions<SqlSettings> sqlOptions)
        {
            _sqlOptions = sqlOptions.Value;
        }
        protected override void OnConfiguring(DbContextOptionsBuilder optionsBuilder)
        {
            if (optionsBuilder.IsConfigured)
            {
                return;
            }

            if (_sqlOptions.InMemory)
            {
                optionsBuilder.UseInMemoryDatabase(_sqlOptions.Database);
                return;
            }

            optionsBuilder.UseSqlServer(_sqlOptions.ConnectionString, b=> b.MigrationsAssembly(_sqlOptions.MigrationInfo));
        }

        protected override void OnModelCreating(ModelBuilder modelBuilder)
        {
            base.OnModelCreating(modelBuilder);

            modelBuilder
           .Entity<User>()
           .Property(e => e.Status)
           .HasConversion(v => v.ToString(), v => (AccountStatusEnum)Enum.Parse(typeof(AccountStatusEnum), v));

            modelBuilder
           .Entity<User>()
           .Property(e => e.Role)
           .HasConversion(v => v.ToString(), v => (RoleEnum)Enum.Parse(typeof(RoleEnum), v));
        }
    }
}
