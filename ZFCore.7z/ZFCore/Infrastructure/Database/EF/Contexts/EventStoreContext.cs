﻿using Database.Entities.Events;
using Microsoft.EntityFrameworkCore;
using Microsoft.Extensions.Options;

namespace Database.Contexts
{
    public class EventStoreContext : DbContext
    {
        private readonly SqlSettings _sqlOptions;
        public DbSet<EventMessage> Users { get; set; }

        public EventStoreContext(IOptions<SqlSettings> sqlOptions)
        {
            _sqlOptions = sqlOptions.Value;
        }
        protected override void OnConfiguring(DbContextOptionsBuilder optionsBuilder)
        {
            if (optionsBuilder.IsConfigured)
            {
                return;
            }

            if (_sqlOptions.InMemory)
            {
                optionsBuilder.UseInMemoryDatabase(_sqlOptions.Database);
                return;
            }

            optionsBuilder.UseSqlServer(_sqlOptions.ConnectionString, b => b.MigrationsAssembly(_sqlOptions.MigrationInfo));
        }

        protected override void OnModelCreating(ModelBuilder modelBuilder)
        {
            base.OnModelCreating(modelBuilder);
        }
    }
}

