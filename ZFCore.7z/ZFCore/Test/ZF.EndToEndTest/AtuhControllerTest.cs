using NUnit.Framework;
using System;
using System.Net.Http;
using System.Threading.Tasks;
using ZF.EndToEndTest.WebHostConfig;

namespace ZF.EndToEndTest
{
    [TestFixture]
    [Category("E2E")]
    public class AtuhControllerTest
    {
        private readonly HttpClient _client;

        public AtuhControllerTest()
        {
            _client = IndentityServerWebHost.Client;
        }


        [Test]
        public async Task  AtuhServicesTest()
        {
            var uriBuilder = new UriBuilder("http://localhost:9001/public/api/auth/");
            uriBuilder.Query = "login='Garibo'&password='cde'";
            _client.BaseAddress = uriBuilder.Uri;

            var content = await _client.GetAsync("Register");
        }
    }
}
