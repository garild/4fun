﻿using Microsoft.AspNetCore;
using Microsoft.AspNetCore.Hosting;
using Microsoft.AspNetCore.TestHost;
using Newtonsoft.Json;
using System;
using System.Net.Http;
using System.Text;
using ZF.IdentityServer;

namespace ZF.EndToEndTest.WebHostConfig
{
    public static class IndentityServerWebHost
    {
        public static HttpClient Client { get; } = new HttpClient();

        static IndentityServerWebHost()
        {
            var server = new TestServer(WebHost.CreateDefaultBuilder()
                .UseEnvironment("Testing")
                .UseUrls("http://localhost:9001")
                .UseStartup<Startup>());

            Client = server.CreateClient();
            Client.BaseAddress = new Uri("public/api/auth/");
        }

        public static void ClearClients()
        {
            Client.Dispose();
        }

        public static StringContent GetContent(object value)
           => new StringContent(JsonConvert.SerializeObject(value), Encoding.UTF8, "application/json");
    }
}
