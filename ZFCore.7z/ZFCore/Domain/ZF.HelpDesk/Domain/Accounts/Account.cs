﻿using System;
using System.Collections.Generic;
using System.Text;
using ZF.SerivceDesk.Domain.Accounts;
using ZF.SerivceDesk.Domain.Accounts.PersonModel;

namespace ZF.HelpDesk.Domain.Accounts
{
    internal class Account
    {
        public string Id { get; set; }
        public PersonData Person { get; set; }
        public PersonData Company { get; set; }
        public StatusEnum Status { get; set; }
        public bool IsCompany { get; set; }
        public DateTime CreateAt { get; set; }
        public DateTime? ModyfiAt { get; set; }
      
    }
}
