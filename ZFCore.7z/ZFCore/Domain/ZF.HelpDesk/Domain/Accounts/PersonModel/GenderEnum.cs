﻿using System;
using System.Collections.Generic;
using System.Text;

namespace ZF.SerivceDesk.Domain.Accounts.PersonModel
{
    internal enum GenderEnum
    {
        Female = 1,
        Male = 2
    }
}
