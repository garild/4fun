﻿using System;
using System.Collections.Generic;
using System.Text;
using ZF.SerivceDesk.Domain.Accounts.PersonModel;

namespace ZF.SerivceDesk.Domain.Accounts
{
    internal class PersonData
    {
        public PersonData(int id, string name, string surname, string phone, GenderEnum gender, Address address)
        {
            Id = id;
            Name = name;
            Surname = surname;
            Phone = phone;
            Gender = gender;
            Address = address;
        }

        public int Id { get; private set; }
        public string Name { get; private set; }
        public string Surname { get; private set; }
        public string Phone { get; private set; }
        public GenderEnum Gender { get; private set; }
        public Address Address { get; private set; }
    }
}
