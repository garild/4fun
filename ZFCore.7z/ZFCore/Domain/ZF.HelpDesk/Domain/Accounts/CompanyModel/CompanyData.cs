﻿using System;
using System.Collections.Generic;
using System.Text;

namespace ZF.SerivceDesk.Domain.Accounts.CompanyModel
{
    class CompanyData
    {
    }
}
