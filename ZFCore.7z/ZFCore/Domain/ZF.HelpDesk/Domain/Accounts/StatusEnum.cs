﻿namespace ZF.SerivceDesk.Domain.Accounts
{
    internal enum StatusEnum
    {
        Active = 1,
        Inactive = 2,
        Suspended = 3,
        NeedVerify = 4
    }
}
