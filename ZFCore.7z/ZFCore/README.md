# ZFCore - swagger endpoint "/swagger"

# This Repository contains

- [x] **DDD** - Domain Driven Design architecture implementation
- [x] **CQRS** - Command Query Responsibility Segregation command patern 
- [x] **WebApi** Service in .Net Core Framework
- [x] **Swagger** - UI provides a display framework that reads an OpenAPI specification document and generates an interactive documentation website 
- [x] **NLog** - provider witch allow to log file/Db info/errors logging of processes etc 
- [x] **JWT** - Json Web Token authorization
- [x] **Database Project** - simply project of database witch is using SQL TOOL to publishing db scheme
- [x] **RabbitMq** - Message broker, advanced message queue communitaction - producer and consumer  - MQ listener
- [x] **Entity Framework Core** - ORM -  object-relational mapper witch allow db (enitites) migration and delivery fluent API for CRUD operation etc
- [x] **Dapper Contrib** - ORM - CRUD operation with LINQ
- [x] **Docker** - containler services builder/publisher
- [x] **NUnit Test** - integration tests  